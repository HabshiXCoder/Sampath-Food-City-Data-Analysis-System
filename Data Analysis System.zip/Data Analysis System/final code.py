import pandas as pd
import matplotlib.pyplot as plt
from abc import ABC, abstractmethod
from datetime import datetime

# Open / Closs Principle
# Abstract Class for Analysis
class Analysis(ABC):
    # Abstract method for performing analysis, to be implemented by subclasses
    @abstractmethod
    def performAnalysis(self, df):
        pass

# Single Responsiblity Principle
# Class for Branch Analysis
class BranchAnalysis(Analysis):
    def performAnalysis(self, df):
        # Loading the CSV file at the start of the analysis method
        df = pd.read_csv(r'C:\Users\a\Desktop\Sample\Data Analysis System\Sampath.csv')
        
        # Grouping data by branch and summing the sales
        result = df.groupby('Branch')['Sales'].sum().reset_index()
        print("\nMONTHLY BRANCH ANALYSIS\n", result)  # Display the result
        
        # Plotting the branch-wise sales in a bar chart
        plt.bar(result['Branch'], result['Sales'], width=0.6, color=['pink', 'lightblue', 'mediumturquoise', 'thistle', 'lightcoral'])
        plt.xlabel("Branches")
        plt.ylabel("Sales")
        plt.title("Monthly Sales Analysis By Branch")
        plt.show()

# Class for Weekly Sales Analysis # Single Responsiblity Principle
class WeeklyAnalysis(Analysis):
    def performAnalysis(self, df):
        # Loading the CSV file at the start of the analysis method
        df = pd.read_csv(r'C:\Users\a\Desktop\Sample\Data Analysis System\Sampath.csv')

        try:
            # Taking input for the starting day of the week
            day1 = int(input("Enter starting day of the week: "))
            day2 = day1 + 6  # Calculating the last day of the week
            # Filtering the data for the selected week
            filtered_df = df[(df['DayOfSale'] >= day1) & (df['DayOfSale'] <= day2)]
            # Grouping by branch and summing the sales
            result = filtered_df.groupby('Branch')['Sales'].sum().reset_index()
            print("\nWEEKLY ANALYSIS\n", result)  # Displaying the result
            # Plotting the sales by branch for the selected week
            plt.bar(result['Branch'], result['Sales'], width=0.6, color=['pink', 'lightblue', 'mediumturquoise', 'thistle', 'lightcoral'])
            plt.xlabel("Branches")
            plt.ylabel("Sales")
            plt.title("Weekly Sales Analysis By Branch")
            plt.show()
        except ValueError:
            print("Invalid input! Please enter a valid day.")  # Handling invalid input



# Class for Price Analysis of Product Category # Single Responsiblity Principle
class PriceAnalysis(Analysis):
    def performAnalysis(self, df):
        # Loading the CSV file at the start of the analysis method
        df = pd.read_csv(r'C:\Users\a\Desktop\Sample\Data Analysis System\Sampath.csv')
        
        # Taking product category as input
        productCategory = input("Enter Product Category: ").strip()
        # Filtering the data based on the selected product category
        filtered_df = df[df['ProductCategory'] == productCategory]
        if filtered_df.empty:
            print("No data found for the selected product category.")
            return  # Returning if no data is found
        print(filtered_df)  # Displaying filtered data
        # Plotting the price trend over time
        plt.plot(filtered_df["DayOfSale"], filtered_df["Price"], marker='o')
        plt.xlabel("Time Period")
        plt.ylabel("Price")
        plt.title(f"Price Analysis of {productCategory}")
        plt.show()

# Class for Product Preference Analysis (based on selected products) # Single Responsiblity Principle
class PreferenceAnalysis(Analysis):
    def performAnalysis(self, df):
        # Loading the CSV file at the start of the analysis method
        df = pd.read_csv(r'C:\Users\a\Desktop\Sample\Data Analysis System\Sampath.csv')

        # Taking selected product names as input
        selected_products = input("Enter product names (comma-separated): ").split(',')
        selected_products = [product.strip() for product in selected_products]  # Removing leading/trailing spaces
        
        # Filtering the data based on the selected products
        filtered_df = df[df['Product'].isin(selected_products)]
        
        if filtered_df.empty:
            print("No sales data found for the selected products.")
            return  # Returning if no data is found
        
        # Grouping data by product and summing the sales
        result = filtered_df.groupby('Product')['Sales'].sum().reset_index()
        print("\nSelected Product Preference Analysis\n", result)  # Displaying the result
        
        # Plotting product preference in a bar chart
        plt.bar(result['Product'], result['Sales'], width=0.6, color=['pink', 'lightblue', 'mediumturquoise', 'thistle', 'lightcoral'])
        plt.xlabel("Products")
        plt.ylabel("Sales")
        plt.title("Selected Product Preference Analysis")
        plt.show()

# Class for Category Preference Analysis
class CategoryPreferenceAnalysis(Analysis):
    def performAnalysis(self, df):
        # Loading the CSV file at the start of the analysis method
        df = pd.read_csv(r'C:\Users\a\Desktop\Sample\Data Analysis System\Sampath.csv')
        
        # Grouping data by product category and summing the sales
        result = df.groupby('ProductCategory')['Sales'].sum().reset_index()
        print("\nCategory Preference Analysis\n", result)  # Displaying the result
        # Plotting category preference in a bar chart
        plt.bar(result['ProductCategory'], result['Sales'], width=0.6, color=['pink', 'lightblue', 'mediumturquoise', 'thistle', 'lightcoral'])
        plt.xlabel("Preference")
        plt.ylabel("Sales")
        plt.title("Product Category Preference Analysis")
        plt.show()

# Class for Distribution Analysis # Single Responsiblity Principle
class DistributionAnalysis(Analysis):
    def performAnalysis(self, df):
        # Loading the CSV file at the start of the analysis method
        df = pd.read_csv(r'C:\Users\a\Desktop\Sample\Data Analysis System\Sampath.csv')
        
        # Grouping data by branch and summing the sales
        result = df.groupby('Branch')['Sales'].sum().reset_index()
        print("\nSales Distribution By Branch\n", result)  # Displaying the result
        # Plotting the sales distribution in a pie chart
        plt.pie(result["Sales"], labels=result["Branch"], autopct='%1.1f%%')
        plt.title("Sales Distribution by Branch")
        plt.show()

# Class for Comparing Sales between Two Branches for a Selected Product Category # Single Responsiblity Principle
class BranchProductCategoryComparisonAnalysis(Analysis):
    def performAnalysis(self, df):
        # Loading the CSV file at the start of the analysis method
        df = pd.read_csv(r'C:\Users\a\Desktop\Sample\Data Analysis System\Sampath.csv')

        # Taking two branch names and product category as input
        branch1 = input("Enter first branch name: ").strip()
        branch2 = input("Enter second branch name: ").strip()
        product_category = input("Enter Product Category: ").strip()

        # Filtering the data based on selected branches and product category
        filtered_df = df[(df['Branch'].isin([branch1, branch2])) & (df['ProductCategory'] == product_category)]

        if filtered_df.empty:
            print(f"No data found for the selected branches: {branch1}, {branch2}, and product category: {product_category}.")
            return  # Returning if no data is found

        # Grouping the filtered data by branch and product category, and summing the sales
        result = filtered_df.groupby(['Branch', 'ProductCategory'])['Sales'].sum().unstack().reset_index()

        print(f"\nSales Comparison between Branches for Product Category '{product_category}'\n", result)  # Displaying result

        # Plotting a bar chart for sales comparison
        result.set_index('Branch').plot(kind='bar', stacked=False, color=['lightcoral', 'mediumturquoise'])
        plt.xlabel("Branches")
        plt.ylabel("Sales")
        plt.title(f"Sales Comparison between {branch1} and {branch2} for {product_category}")
        plt.show()

#Liskov Substitution Principle
# Class for Strategy Execution
class ProcessStrategy:
    def executeStrategy(self, analysis_object, df):
        # Perform the analysis using the passed analysis object
        analysis_object.performAnalysis(df)

# Class for Selecting and Executing Strategies
class StrategySelector:
    def openMenu(self):
        try:
            # Load the data once when the menu is opened
            df = pd.read_csv(r'C:\Users\a\Desktop\Sample\Data Analysis System\Sampath.csv')  # Ensure the file path is correct
        except FileNotFoundError:
            print("Error: Data file not found. Please check the path.")
            return
        # Dictionary of available analysis options
        analysis_options = {
            1: BranchAnalysis(),
            2: WeeklyAnalysis(),
            3: PriceAnalysis(),
            4: PreferenceAnalysis(),
            5: CategoryPreferenceAnalysis(),
            6: DistributionAnalysis(),
            7: BranchProductCategoryComparisonAnalysis()
        }
        while True:
            # Menu display for the user
            print("\nSAMPATH FOOD CITY PVT LTD - Data Analysis\n")
            print("1 - Analysis By Branch")
            print("2 - Weekly Analysis of Sales")
            print("3 - Price Analysis of Product Category")
            print("4 - Product Preference Analysis")
            print("5 - Category Preference Analysis")
            print("6 - Distribution Analysis of Sales")
            print("7 - Branch Comparison for Selected Product Category")
            print("8 - Exit")
            try:
                # Taking the user’s choice for the analysis option
                choice = int(input("Enter Choice [1|2|3|4|5|6|7|8]: "))
                if choice == 8:
                    print("Exiting the system. Goodbye!")  # Exit the program
                    break
                elif choice in analysis_options:
                    # Execute the selected analysis strategy
                    ProcessStrategy().executeStrategy(analysis_options[choice], df)
                else:
                    print("Invalid Choice. Please enter a valid option.")
            except ValueError:
                print("Invalid input! Please enter a number between 1 and 8.")

# Admin Class (Singleton Pattern)
class Admin:
    _instance = None  # Singleton pattern to ensure only one admin instance
    
    def __new__(cls, username, password):
        if cls._instance is None:
            cls._instance = super(Admin, cls).__new__(cls)
            cls._instance.username = username
            cls._instance.password = password
            return cls._instance
        else:
            print("Admin already exists. Cannot create another admin.")
            return None

    def login(self):
        # Admin login method
        print("\nSAMPATH FOOD CITY PVT Ltd - Data Analysis System\n")
        print("--------------------------------------------------")
        un = input("Enter User Name: ")
        pw = input("Enter Password: ")
        if un == self.username and pw == self.password:
            # If login is successful, open the menu for analysis options
            StrategySelector().openMenu()
        else:
            print("Incorrect User Name OR Password")

# Main Execution
admin1 = Admin("Habshi", "1234")  # First admin user
admin2 = Admin("Ahamed", "5678")  # Will print an error if trying to create another admin instance

if admin1:  # Only if admin was successfully created
    admin1.login()  # Login for the admin
